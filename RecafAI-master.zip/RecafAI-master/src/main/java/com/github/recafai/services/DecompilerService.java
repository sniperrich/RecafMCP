package com.github.recafai.services;

public class DecompilerService {
}
